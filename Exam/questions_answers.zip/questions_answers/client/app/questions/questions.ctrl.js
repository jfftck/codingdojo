(function() {
    'use strict';

    angular
        .module('app')
        .controller('QuestionsIndexController', QuestionsIndexController);

    QuestionsIndexController.$inject = ['$location'];

    /* @ngInject */
    function QuestionsIndexController($location) {
        var vm = this;

        vm.name = '';

        activate();

        function activate() {
            var name = $cookies.get('name');

            $log.debug(name);

            if (name) {
                vm.name = name;
            }
        }
    }
})();
