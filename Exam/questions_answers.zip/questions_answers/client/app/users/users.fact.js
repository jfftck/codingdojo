(function() {
    'use strict';

    angular
        .module('app')
        .factory('userFactory', userFactory);

    userFactory.$inject = ['$http', '$log'];

    /* @ngInject */
    function userFactory($http, $log) {
        var service = {
            login: login,
            errors: errors
        };
        var errors = null;

        return service;

        function errors() {
            return errors;
        }

        function login(name, callback) {
            errors = null;

            $http.post('/login', {name: name}).then(success, failed);

            function success(response) {
                callback(response);
            }

            function failed(response) {
                errors = response;

                callback(null);
            }
        }
    }
})();
